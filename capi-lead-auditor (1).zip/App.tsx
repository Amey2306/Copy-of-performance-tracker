import React, { useState } from 'react';
import { RawRow, AnalysisResult, AppState, ProjectContext, InputMethod } from './types';
import { parseExcelFile, exportToExcel } from './services/excelService';
import { analyzeLeadBatch } from './services/geminiService';
import FileUpload from './components/FileUpload';
import ColumnSelector from './components/ColumnSelector';
import ProjectContextInput from './components/ProjectContextInput';
import ProjectManager from './components/ProjectManager';
import AnalysisView from './components/AnalysisView';
import InputMethodSelector from './components/InputMethodSelector';
import GoogleSheetsSelector from './components/GoogleSheetsSelector';
import RealTimeInput from './components/RealTimeInput';
import Dashboard from './components/Dashboard';
import GlobalDashboard from './components/GlobalDashboard';
import TagManager from './components/TagManager';
import { Bot, Loader2, Building2, LayoutDashboard, BarChart3, Settings, PieChart } from 'lucide-react';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.CONTEXT_SETUP);
  const [inputMethod, setInputMethod] = useState<InputMethod | null>(null);
  const [rawFile, setRawFile] = useState<File | null>(null);
  const [rawData, setRawData] = useState<RawRow[]>([]);
  const [mappedColumn, setMappedColumn] = useState<string>('');
  const [validationColumn, setValidationColumn] = useState<string | undefined>(undefined);
  const [agencyColumn, setAgencyColumn] = useState<string | undefined>(undefined);
  const [projects, setProjects] = useState<ProjectContext[]>(() => {
    try {
      const saved = localStorage.getItem('capi_projects');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Failed to parse projects from localStorage", e);
      return [];
    }
  });
  const [projectContext, setProjectContext] = useState<ProjectContext | null>(null);
  const [editingProject, setEditingProject] = useState<ProjectContext | null>(null);
  const [isAddingProject, setIsAddingProject] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([]);
  const [progress, setProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });

  const handleProjectContextConfirm = (context: ProjectContext) => {
    const updatedProjects = editingProject
      ? projects.map(p => p.id === context.id ? context : p)
      : [...projects, context];
    
    setProjects(updatedProjects);
    localStorage.setItem('capi_projects', JSON.stringify(updatedProjects));
    setIsAddingProject(false);
    setEditingProject(null);
  };

  const handleProjectSelect = (project: ProjectContext) => {
    setProjectContext(project);
    setAppState(AppState.INPUT_METHOD);
  };

  const handleProjectDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      const updatedProjects = projects.filter(p => p.id !== id);
      setProjects(updatedProjects);
      localStorage.setItem('capi_projects', JSON.stringify(updatedProjects));
    }
  };

  const handleInputMethodSelect = (method: InputMethod) => {
    setInputMethod(method);
    if (method === InputMethod.FILE) {
      setAppState(AppState.UPLOAD);
    } else if (method === InputMethod.GOOGLE_SHEETS) {
      setAppState(AppState.SHEETS);
    } else if (method === InputMethod.COPY_PASTE) {
      setAppState(AppState.REALTIME);
    }
  };

  const handleFileSelect = async (file: File) => {
    try {
      const data = await parseExcelFile(file);
      if (data.length === 0) {
        alert("The uploaded file appears to be empty.");
        return;
      }
      setRawFile(file);
      setRawData(data);
      setAppState(AppState.MAPPING);
    } catch (error) {
      console.error("Error parsing file:", error);
      alert("Failed to parse the file. Please ensure it is a valid Excel/CSV file.");
    }
  };

  const handleDataLoaded = (data: RawRow[]) => {
    setRawData(data);
    setAppState(AppState.MAPPING);
  };

  const handleColumnConfirm = (columnName: string, valCol?: string, agCol?: string) => {
    setMappedColumn(columnName);
    setValidationColumn(valCol);
    setAgencyColumn(agCol);
    setAppState(AppState.PROCESSING);
    if (projectContext) {
      performAnalysis(rawData, columnName, projectContext);
    }
  };

  const handleRealTimeAnalysisComplete = (result: AnalysisResult) => {
    setAnalysisResults(prev => [result, ...prev]);
    setAppState(AppState.RESULTS);
    setMappedColumn('Comment');
  };

  const performAnalysis = async (data: RawRow[], noteCol: string, context: ProjectContext) => {
    const BATCH_SIZE = 20;
    let allResults: AnalysisResult[] = [];

    setProgress({ current: 0, total: data.length });

    for (let i = 0; i < data.length; i += BATCH_SIZE) {
      const batchSlice = data.slice(i, i + BATCH_SIZE);
      const batchInput = batchSlice.map((row, index) => ({
        rowId: i + index,
        text: String(row[noteCol] || '')
      }));

      const nonEmptyItems = batchInput.filter(item => item.text.trim().length > 2);
      
      let batchResults: Array<{ rowId: number, capiUpdated: boolean, reason: string, confidenceScore: number, tags: string[] }> = [];
      
      if (nonEmptyItems.length > 0) {
        batchResults = await analyzeLeadBatch(nonEmptyItems, context);
      }

      const mergedBatch = batchInput.map(input => {
        const found = batchResults.find(r => r.rowId === input.rowId);
        return {
          rowId: input.rowId,
          originalData: batchSlice[input.rowId - i],
          capiUpdated: found ? found.capiUpdated : false,
          reason: found ? found.reason : (input.text.trim().length <= 2 ? 'Empty or too short' : 'Analysis failed'),
          confidenceScore: found ? found.confidenceScore : 0,
          tags: found ? found.tags : []
        };
      });

      allResults = [...allResults, ...mergedBatch];
      setProgress({ current: Math.min(i + BATCH_SIZE, data.length), total: data.length });
    }

    setAnalysisResults(allResults);
    
    // Update project stats
    const qualifiedCount = allResults.filter(r => r.capiUpdated).length;
    const updatedProjects = projects.map(p => {
      if (p.id === context.id) {
        return {
          ...p,
          lastAnalysisStats: {
            total: allResults.length,
            qualified: qualifiedCount,
            timestamp: new Date().toISOString()
          }
        };
      }
      return p;
    });
    setProjects(updatedProjects);
    localStorage.setItem('capi_projects', JSON.stringify(updatedProjects));
    
    setAppState(AppState.RESULTS);
  };

  const handleExport = () => {
    if (analysisResults.length > 0) {
      exportToExcel(analysisResults, rawFile?.name || 'analysis_results.xlsx');
    }
  };

  const handleReset = () => {
    setAppState(AppState.CONTEXT_SETUP);
    setRawFile(null);
    setRawData([]);
    setAnalysisResults([]);
    setMappedColumn('');
    setValidationColumn(undefined);
    setProjectContext(null);
    setInputMethod(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 leading-tight">CAPI Lead Auditor</h1>
              <p className="text-xs text-slate-500">Powered by Gemini AI</p>
            </div>
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-500">
             {projectContext && (
               <span className="hidden md:flex items-center gap-1 bg-blue-50 text-blue-700 px-2 py-1 rounded border border-blue-100">
                 <Building2 className="w-3 h-3" />
                 {projectContext.projectName}
               </span>
             )}
             {appState !== AppState.CONTEXT_SETUP && rawFile?.name}
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setAppState(AppState.GLOBAL_DASHBOARD)}
              className="flex items-center gap-2 px-3 py-1.5 text-slate-600 rounded-lg hover:bg-slate-100 transition-colors text-sm font-medium"
              title="Global Dashboard"
            >
              <PieChart className="w-4 h-4" />
              <span className="hidden sm:inline">Global Insights</span>
            </button>
            <button 
              onClick={() => setAppState(AppState.TAG_MANAGEMENT)}
              className="flex items-center gap-2 px-3 py-1.5 text-slate-600 rounded-lg hover:bg-slate-100 transition-colors text-sm font-medium"
              title="Tag Management"
            >
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Tags</span>
            </button>
            {analysisResults.length > 0 && appState !== AppState.DASHBOARD && (
              <button 
                onClick={() => setAppState(AppState.DASHBOARD)}
                className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
              >
                <BarChart3 className="w-4 h-4" />
                View Dashboard
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {appState === AppState.CONTEXT_SETUP && (
          <div className="animate-fade-in-up">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Step 1: Define Project Context</h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Start by defining the criteria for your project. This will be used by the AI to qualify leads.
              </p>
            </div>
            
            <ProjectManager
              projects={projects}
              onAdd={() => setIsAddingProject(true)}
              onEdit={(p) => setEditingProject(p)}
              onDelete={handleProjectDelete}
              onSelect={handleProjectSelect}
            />

            {(isAddingProject || editingProject) && (
              <ProjectContextInput
                initialData={editingProject}
                onConfirm={handleProjectContextConfirm}
                onCancel={() => {
                  setIsAddingProject(false);
                  setEditingProject(null);
                }}
              />
            )}
          </div>
        )}

        {appState === AppState.INPUT_METHOD && (
          <InputMethodSelector 
            onSelect={handleInputMethodSelect}
            onBack={() => setAppState(AppState.CONTEXT_SETUP)}
          />
        )}

        {appState === AppState.UPLOAD && (
          <div className="animate-fade-in-up">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Upload Sheet</h2>
              <p className="text-lg text-slate-600">Upload your Excel or CSV file to begin analysis.</p>
            </div>
            <FileUpload onFileSelect={handleFileSelect} />
            <div className="mt-8 text-center">
              <button onClick={() => setAppState(AppState.INPUT_METHOD)} className="text-slate-500 hover:text-slate-800 underline">Change Input Method</button>
            </div>
          </div>
        )}

        {appState === AppState.SHEETS && (
          <GoogleSheetsSelector 
            onDataLoaded={handleDataLoaded}
            onCancel={() => setAppState(AppState.INPUT_METHOD)}
          />
        )}

        {appState === AppState.REALTIME && projectContext && (
          <RealTimeInput 
            projectContext={projectContext}
            onAnalysisComplete={handleRealTimeAnalysisComplete}
            onBack={() => setAppState(AppState.INPUT_METHOD)}
          />
        )}

        {appState === AppState.MAPPING && (
          <ColumnSelector 
            data={rawData} 
            onConfirm={handleColumnConfirm} 
            onCancel={() => setAppState(AppState.INPUT_METHOD)} 
          />
        )}

        {appState === AppState.PROCESSING && projectContext && (
          <div className="max-w-2xl mx-auto text-center mt-20 animate-fade-in">
             <div className="relative w-24 h-24 mx-auto mb-8">
                <div className="absolute inset-0 border-4 border-slate-200 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
                <Loader2 className="absolute inset-0 m-auto w-8 h-8 text-blue-600 animate-pulse" />
             </div>
             
             <h2 className="text-2xl font-bold text-slate-900 mb-2">Analyzing Calls for {projectContext.projectName}...</h2>
             <p className="text-slate-500 mb-8">
               Verifying matches against {projectContext.startBudget} Cr, {projectContext.configurations.length} configurations, {projectContext.location}.
             </p>
             
             <div className="bg-white rounded-full h-4 w-full shadow-inner border border-slate-100 overflow-hidden relative">
                <div 
                  className="bg-blue-600 h-full transition-all duration-300 ease-out"
                  style={{ width: `${(progress.current / progress.total) * 100}%` }}
                ></div>
             </div>
             <p className="text-sm text-slate-400 mt-2 font-mono">
               Processing {progress.current} of {progress.total} records
             </p>
          </div>
        )}

        {appState === AppState.RESULTS && (
          <AnalysisView 
            results={analysisResults} 
            mappedColumn={mappedColumn} 
            validationColumn={validationColumn}
            agencyColumn={agencyColumn}
            projectContext={projectContext}
            onExport={handleExport}
            onReset={handleReset}
            onViewDashboard={() => setAppState(AppState.DASHBOARD)}
          />
        )}

        {appState === AppState.DASHBOARD && (
          <Dashboard 
            results={analysisResults}
            projectContext={projectContext}
            agencyColumn={agencyColumn}
            onBack={() => setAppState(AppState.RESULTS)}
          />
        )}

        {appState === AppState.GLOBAL_DASHBOARD && (
          <GlobalDashboard 
            projects={projects}
            onBack={() => setAppState(AppState.CONTEXT_SETUP)}
          />
        )}

        {appState === AppState.TAG_MANAGEMENT && (
          <TagManager 
            onBack={() => setAppState(AppState.CONTEXT_SETUP)}
          />
        )}
      </main>
    </div>
  );
};

export default App;
