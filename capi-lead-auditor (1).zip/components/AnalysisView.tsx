import React, { useState } from 'react';
import { AnalysisResult, ProcessingStats, ProjectContext } from '../types';
import { Download, CheckCircle, XCircle, Filter, PieChart, ShieldCheck, MapPin, IndianRupee, LayoutDashboard, Calendar, BarChart3 } from 'lucide-react';

interface AnalysisViewProps {
  results: AnalysisResult[];
  mappedColumn: string;
  validationColumn?: string;
  agencyColumn?: string;
  projectContext: ProjectContext | null;
  onExport: () => void;
  onReset: () => void;
  onViewDashboard: () => void;
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ results, mappedColumn, validationColumn, agencyColumn, projectContext, onExport, onReset, onViewDashboard }) => {
  const [filter, setFilter] = useState<'ALL' | 'VALID' | 'INVALID'>('ALL');

  const stats: ProcessingStats = {
    total: results.length,
    processed: results.length,
    validCapi: results.filter(r => r.capiUpdated).length,
    invalidCapi: results.filter(r => !r.capiUpdated).length
  };

  const filteredResults = results.filter(r => {
    if (filter === 'VALID') return r.capiUpdated;
    if (filter === 'INVALID') return !r.capiUpdated;
    return true;
  });

  const getConfidenceColor = (score: number) => {
    if (score >= 0.8) return 'text-green-600 bg-green-50 border-green-200';
    if (score >= 0.5) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-red-600 bg-red-50 border-red-200';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* 1. Criteria Context Card (The "Input" check) */}
      {projectContext && (
        <div className="bg-slate-800 text-white rounded-xl shadow-md overflow-hidden">
           <div className="p-4 border-b border-slate-700 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
              <h3 className="font-semibold text-lg">Analysis Criteria: {projectContext.projectName}</h3>
           </div>
           <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                 <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                    <IndianRupee className="w-3.5 h-3.5" /> Budget
                 </div>
                 <div className="font-medium">{projectContext.startBudget}</div>
              </div>
              <div>
                 <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                    <MapPin className="w-3.5 h-3.5" /> Location
                 </div>
                 <div className="font-medium">{projectContext.location}</div>
              </div>
              <div>
                 <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                    <LayoutDashboard className="w-3.5 h-3.5" /> Configs
                 </div>
                 <div className="font-medium">
                    {projectContext.configurations.map(c => c.type).join(', ')}
                 </div>
              </div>
              <div>
                 <div className="flex items-center gap-1.5 text-slate-400 mb-1">
                    <Calendar className="w-3.5 h-3.5" /> Possession
                 </div>
                 <div className="font-medium">{projectContext.targetPossession}</div>
              </div>
           </div>
           <div className="bg-slate-900/50 p-2 text-center text-xs text-slate-400">
              Matches required: 2 out of 4
           </div>
        </div>
      )}

      {/* 2. Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-500">Total Leads</p>
              <h3 className="text-2xl font-bold text-slate-900">{stats.total}</h3>
            </div>
            <div className="p-3 bg-slate-100 rounded-lg">
              <PieChart className="w-6 h-6 text-slate-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-green-100 shadow-sm bg-gradient-to-br from-white to-green-50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-green-600">CAPI Qualified</p>
              <h3 className="text-2xl font-bold text-green-700">{stats.validCapi}</h3>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-red-100 shadow-sm bg-gradient-to-br from-white to-red-50">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-red-600">Non-CAPI</p>
              <h3 className="text-2xl font-bold text-red-700">{stats.invalidCapi}</h3>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <XCircle className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-blue-600 p-5 rounded-xl shadow-lg shadow-blue-200 text-white flex flex-col justify-center items-center text-center cursor-pointer hover:bg-blue-700 transition-colors" onClick={onExport}>
           <Download className="w-8 h-8 mb-2" />
           <span className="font-semibold">Export Updated Excel</span>
        </div>

        <div className="bg-indigo-600 p-5 rounded-xl shadow-lg shadow-indigo-200 text-white flex flex-col justify-center items-center text-center cursor-pointer hover:bg-indigo-700 transition-colors" onClick={onViewDashboard}>
           <BarChart3 className="w-8 h-8 mb-2" />
           <span className="font-semibold">View Insights Dashboard</span>
        </div>
      </div>

      {/* 3. Main Table Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-lg font-bold text-slate-800">Analysis Details</h2>
          
          <div className="flex bg-slate-100 p-1 rounded-lg">
            {(['ALL', 'VALID', 'INVALID'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`
                  px-4 py-1.5 text-sm font-medium rounded-md transition-all
                  ${filter === f 
                    ? 'bg-white text-slate-900 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-700'
                  }
                `}
              >
                {f.charAt(0) + f.slice(1).toLowerCase()}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase text-slate-500 tracking-wider">
                <th className="px-6 py-4 font-semibold w-16">#</th>
                <th className="px-6 py-4 font-semibold min-w-[250px]">Original Note ({mappedColumn})</th>
                {agencyColumn && (
                  <th className="px-6 py-4 font-semibold w-32 bg-emerald-50/50 text-emerald-900 border-l border-emerald-100">
                    Agency ({agencyColumn})
                  </th>
                )}
                {validationColumn && (
                  <th className="px-6 py-4 font-semibold w-32 bg-indigo-50/50 text-indigo-900 border-l border-indigo-100">
                    Orig. Status ({validationColumn})
                  </th>
                )}
                <th className={`px-6 py-4 font-semibold w-32 ${validationColumn ? 'bg-blue-50/50 text-blue-900 border-l border-blue-100' : ''}`}>
                   AI Status
                </th>
                <th className="px-6 py-4 font-semibold w-24">Conf.</th>
                <th className="px-6 py-4 font-semibold min-w-[200px]">Tags</th>
                <th className="px-6 py-4 font-semibold min-w-[250px]">AI Reasoning</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredResults.map((result, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 text-sm text-slate-400 font-mono">
                    {idx + 1}
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-700 line-clamp-3" title={String(result.originalData[mappedColumn] || '')}>
                      {String(result.originalData[mappedColumn] || '')}
                    </p>
                  </td>
                  
                  {/* Agency Column */}
                  {agencyColumn && (
                    <td className="px-6 py-4 text-sm font-medium text-slate-600 bg-emerald-50/30 border-l border-emerald-50">
                      {String(result.originalData[agencyColumn] || '-')}
                    </td>
                  )}

                  {/* Validation Column */}
                  {validationColumn && (
                    <td className="px-6 py-4 text-sm font-medium text-slate-600 bg-indigo-50/30 border-l border-indigo-50">
                      {String(result.originalData[validationColumn] || '-')}
                    </td>
                  )}

                  {/* AI Status */}
                  <td className={`px-6 py-4 ${validationColumn ? 'bg-blue-50/30 border-l border-blue-50' : ''}`}>
                    {result.capiUpdated ? (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        CAPI
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        <XCircle className="w-3 h-3 mr-1" />
                        No
                      </span>
                    )}
                  </td>
                  
                  {/* Confidence Score */}
                  <td className="px-6 py-4">
                    {result.confidenceScore !== undefined ? (
                       <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold border ${getConfidenceColor(result.confidenceScore)}`}>
                         {Math.round(result.confidenceScore * 100)}%
                       </span>
                    ) : (
                       <span className="text-slate-300 text-xs">-</span>
                    )}
                  </td>

                  {/* Tags */}
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {result.tags && result.tags.length > 0 ? (
                        result.tags.map((tag, tIdx) => (
                          <span 
                            key={tIdx} 
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              tag.includes('Hot') ? 'bg-orange-100 text-orange-700' : 
                              tag.includes('Mismatch') || tag.includes('Issue') ? 'bg-red-50 text-red-600 border border-red-100' :
                              'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {tag}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-300 text-xs">-</span>
                      )}
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-600">
                      {result.reason}
                    </p>
                  </td>
                </tr>
              ))}
              
              {filteredResults.length === 0 && (
                <tr>
                  <td colSpan={validationColumn ? 6 : 5} className="px-6 py-12 text-center text-slate-400">
                    No records found for this filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 border-t border-slate-100 bg-slate-50 text-xs text-slate-500 flex justify-between">
           <span>Showing {filteredResults.length} of {stats.total} records</span>
           <button onClick={onReset} className="text-blue-600 hover:underline">Start Over</button>
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;
