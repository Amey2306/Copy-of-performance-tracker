import React, { useState } from 'react';
import { RawRow } from '../types';
import { Search, ArrowRight, ShieldCheck } from 'lucide-react';

interface ColumnSelectorProps {
  data: RawRow[];
  onConfirm: (columnName: string, validationColumn?: string, agencyColumn?: string) => void;
  onCancel: () => void;
}

const ColumnSelector: React.FC<ColumnSelectorProps> = ({ data, onConfirm, onCancel }) => {
  const [selectedColumn, setSelectedColumn] = useState<string>('');
  const [validationColumn, setValidationColumn] = useState<string>('');
  const [agencyColumn, setAgencyColumn] = useState<string>('');
  
  if (!data || data.length === 0) return null;

  const columns = Object.keys(data[0]);
  
  // Auto-detection logic (simple heuristics)
  React.useEffect(() => {
    const noteCandidates = ['comment', 'note', 'remark', 'description', 'feedback'];
    const foundNote = columns.find(col => 
      noteCandidates.some(candidate => col.toLowerCase().includes(candidate))
    );
    if (foundNote) setSelectedColumn(foundNote);

    const statusCandidates = ['status', 'stage', 'disposition', 'capi'];
    const foundStatus = columns.find(col => 
      statusCandidates.some(candidate => col.toLowerCase().includes(candidate)) && col !== foundNote
    );
    if (foundStatus) setValidationColumn(foundStatus);

    const agencyCandidates = ['agency', 'source', 'platform', 'lead source', 'channel', 'publisher'];
    const foundAgency = columns.find(col => 
      agencyCandidates.some(candidate => col.toLowerCase().includes(candidate)) && col !== foundNote && col !== foundStatus
    );
    if (foundAgency) setAgencyColumn(foundAgency);
  }, []);

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-xl font-bold text-slate-900">Map Data Columns</h2>
        <p className="text-slate-500 text-sm mt-1">
          Select the columns for analysis.
        </p>
      </div>

      <div className="p-6 space-y-8">
        {/* Primary Input */}
        <div className="space-y-3">
          <label className="block text-sm font-medium text-slate-700">
            1. Select Call Notes Column <span className="text-red-500">*</span>
            <span className="block text-xs font-normal text-slate-500 mt-0.5">The column containing the discussion text to analyze.</span>
          </label>
          <div className="relative">
            <select
              value={selectedColumn}
              onChange={(e) => setSelectedColumn(e.target.value)}
              className="block w-full pl-3 pr-10 py-3 text-base border-slate-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-lg border bg-slate-50"
            >
              <option value="" disabled>-- Select Notes Column --</option>
              {columns.map((col) => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Optional Validation Input */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-start gap-3">
               <ShieldCheck className="w-5 h-5 text-indigo-600 mt-0.5" />
               <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700">
                    2. Existing Status Column (Optional)
                  </label>
                  <p className="text-xs text-slate-500 mt-1 mb-2">
                     Compare AI results with your current CRM status.
                  </p>
                  <div className="relative bg-white rounded-md">
                    <select
                      value={validationColumn}
                      onChange={(e) => setValidationColumn(e.target.value)}
                      className="block w-full pl-3 pr-10 py-2 text-sm border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 rounded-lg border"
                    >
                      <option value="">-- No Validation Column --</option>
                      {columns.filter(c => c !== selectedColumn && c !== agencyColumn).map((col) => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
               </div>
            </div>
          </div>

          <div className="space-y-3 p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div className="flex items-start gap-3">
               <Search className="w-5 h-5 text-emerald-600 mt-0.5" />
               <div className="flex-1">
                  <label className="block text-sm font-medium text-slate-700">
                    3. Agency/Source Column (Optional)
                  </label>
                  <p className="text-xs text-slate-500 mt-1 mb-2">
                     Analyze performance by agency, platform, or lead source.
                  </p>
                  <div className="relative bg-white rounded-md">
                    <select
                      value={agencyColumn}
                      onChange={(e) => setAgencyColumn(e.target.value)}
                      className="block w-full pl-3 pr-10 py-2 text-sm border-slate-300 focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 rounded-lg border"
                    >
                      <option value="">-- No Agency Column --</option>
                      {columns.filter(c => c !== selectedColumn && c !== validationColumn).map((col) => (
                        <option key={col} value={col}>{col}</option>
                      ))}
                    </select>
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Preview Section */}
        {selectedColumn && (
          <div className="mt-4">
            <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
              Data Preview
            </h4>
            <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-2 border border-slate-200 rounded-lg">
              <table className="w-full text-left text-sm">
                 <thead className="bg-slate-50 sticky top-0">
                    <tr>
                      <th className="p-2 font-medium text-slate-600 border-b">Note ({selectedColumn})</th>
                      {validationColumn && <th className="p-2 font-medium text-slate-600 border-b">Status ({validationColumn})</th>}
                      {agencyColumn && <th className="p-2 font-medium text-slate-600 border-b">Agency ({agencyColumn})</th>}
                    </tr>
                 </thead>
                 <tbody>
                    {data.slice(0, 3).map((row, idx) => (
                      <tr key={idx} className="border-b last:border-0 hover:bg-slate-50">
                        <td className="p-2 text-slate-600 align-top">
                           <p className="line-clamp-2">{String(row[selectedColumn] || '')}</p>
                        </td>
                        {validationColumn && (
                           <td className="p-2 text-slate-500 align-top font-mono text-xs">
                              {String(row[validationColumn] || '-')}
                           </td>
                        )}
                        {agencyColumn && (
                           <td className="p-2 text-slate-500 align-top font-mono text-xs">
                              {String(row[agencyColumn] || '-')}
                           </td>
                        )}
                      </tr>
                    ))}
                 </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
        <button
          onClick={onCancel}
          className="text-slate-600 hover:text-slate-800 text-sm font-medium px-4 py-2"
        >
          Cancel & Upload New
        </button>
        <button
          onClick={() => onConfirm(selectedColumn, validationColumn, agencyColumn)}
          disabled={!selectedColumn}
          className={`
            flex items-center space-x-2 px-6 py-2.5 rounded-lg text-white font-medium transition-colors
            ${selectedColumn 
              ? 'bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-200' 
              : 'bg-slate-300 cursor-not-allowed'
            }
          `}
        >
          <span>Start Analysis</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default ColumnSelector;
