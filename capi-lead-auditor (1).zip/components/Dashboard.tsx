import React, { useMemo } from 'react';
import { AnalysisResult, ProjectContext } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { 
  TrendingUp, Users, CheckCircle2, XCircle, AlertCircle, 
  ArrowLeft, Download, Filter, BarChart3, PieChart as PieChartIcon,
  Target, Zap, ShieldCheck
} from 'lucide-react';

interface DashboardProps {
  results: AnalysisResult[];
  projectContext: ProjectContext | null;
  agencyColumn?: string;
  onBack: () => void;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316'];

const Dashboard: React.FC<DashboardProps> = ({ results, projectContext, agencyColumn, onBack }) => {
  const stats = useMemo(() => {
    if (results.length === 0) return null;

    const total = results.length;
    const capiYes = results.filter(r => r.capiUpdated).length;
    const capiNo = total - capiYes;
    const avgConfidence = results.reduce((acc, r) => acc + (r.confidenceScore || 0), 0) / total;

    // Agency Performance
    const agencyStats: Record<string, { total: number, qualified: number }> = {};
    if (agencyColumn) {
      results.forEach(r => {
        const agency = String(r.originalData[agencyColumn] || 'Unknown');
        if (!agencyStats[agency]) agencyStats[agency] = { total: 0, qualified: 0 };
        agencyStats[agency].total++;
        if (r.capiUpdated) agencyStats[agency].qualified++;
      });
    }

    const agencyData = Object.entries(agencyStats)
      .map(([name, data]) => ({
        name,
        total: data.total,
        qualified: data.qualified,
        rate: (data.qualified / data.total) * 100
      }))
      .sort((a, b) => b.rate - a.rate);

    // Tags distribution
    const tagCounts: Record<string, number> = {};
    results.forEach(r => {
      r.tags?.forEach(tag => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });
    const tagData = Object.entries(tagCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);

    // Confidence distribution
    const confidenceDist = [
      { range: '0-20', count: 0 },
      { range: '21-40', count: 0 },
      { range: '41-60', count: 0 },
      { range: '61-80', count: 0 },
      { range: '81-100', count: 0 },
    ];
    results.forEach(r => {
      const score = r.confidenceScore || 0;
      if (score <= 20) confidenceDist[0].count++;
      else if (score <= 40) confidenceDist[1].count++;
      else if (score <= 60) confidenceDist[2].count++;
      else if (score <= 80) confidenceDist[3].count++;
      else confidenceDist[4].count++;
    });

    // Reason analysis (simple keyword matching for "metrics")
    const metrics = [
      { name: 'Budget', match: 0, mismatch: 0 },
      { name: 'Location', match: 0, mismatch: 0 },
      { name: 'Configuration', match: 0, mismatch: 0 },
      { name: 'Possession', match: 0, mismatch: 0 },
    ];

    results.forEach(r => {
      const reason = r.reason.toLowerCase();
      const isQualified = r.capiUpdated;
      
      // Heuristic: if qualified, all mentioned parameters matched. 
      // If not qualified, the reason usually mentions what failed.
      if (isQualified) {
        metrics[0].match++;
        metrics[1].match++;
        metrics[2].match++;
        metrics[3].match++;
      } else {
        if (reason.includes('budget')) metrics[0].mismatch++; else metrics[0].match++;
        if (reason.includes('location')) metrics[1].mismatch++; else metrics[1].match++;
        if (reason.includes('config') || reason.includes('bhk')) metrics[2].mismatch++; else metrics[2].match++;
        if (reason.includes('possession') || reason.includes('ready')) metrics[3].mismatch++; else metrics[3].match++;
      }
    });

    return {
      total,
      capiYes,
      capiNo,
      avgConfidence,
      tagData,
      confidenceDist,
      metrics,
      agencyData,
      capiRate: (capiYes / total) * 100
    };
  }, [results, agencyColumn]);

  if (!stats) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border border-slate-200 shadow-sm">
        <BarChart3 className="w-16 h-16 text-slate-200 mb-4" />
        <h3 className="text-xl font-semibold text-slate-900">No Data Available</h3>
        <p className="text-slate-500 mb-6">Complete an analysis to see insights.</p>
        <button 
          onClick={onBack}
          className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Analysis
        </button>
      </div>
    );
  }

  const pieData = [
    { name: 'CAPI Qualified', value: stats.capiYes },
    { name: 'Not Qualified', value: stats.capiNo },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Analysis Dashboard</h2>
          <p className="text-slate-500">
            {projectContext ? `Insights for ${projectContext.projectName}` : 'Overall Analysis Insights'}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-slate-600"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Leads</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.total}</div>
          <div className="mt-2 text-sm text-slate-500">Analyzed in this session</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">CAPI Rate</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.capiRate.toFixed(1)}%</div>
          <div className="mt-2 text-sm text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            {stats.capiYes} leads qualified
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-amber-50 rounded-lg">
              <Zap className="w-6 h-6 text-amber-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Avg Confidence</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.avgConfidence.toFixed(1)}%</div>
          <div className="mt-2 text-sm text-slate-500">AI prediction reliability</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-50 rounded-lg">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Top Tag</span>
          </div>
          <div className="text-2xl font-bold text-slate-900 truncate">
            {stats.tagData[0]?.name || 'N/A'}
          </div>
          <div className="mt-2 text-sm text-slate-500">Most frequent lead category</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* CAPI Qualification Pie */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <PieChartIcon className="w-5 h-5 text-blue-600" />
              Qualification Breakdown
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : '#ef4444'} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Metrics Performance Bar */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Criteria Performance
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.metrics} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={100} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Legend />
                <Bar dataKey="match" name="Matched" fill="#10b981" radius={[0, 4, 4, 0]} barSize={20} />
                <Bar dataKey="mismatch" name="Mismatched" fill="#ef4444" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Confidence Score Distribution */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
              Confidence Distribution
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.confidenceDist}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="range" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="count" stroke="#3b82f6" fillOpacity={1} fill="url(#colorCount)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Tags / Platforms */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Filter className="w-5 h-5 text-blue-600" />
              Lead Categorization (Tags)
            </h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.tagData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={30}>
                  {stats.tagData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Agency Performance */}
        {agencyColumn && stats.agencyData.length > 0 && (
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Agency Performance (CAPI Rate %)
              </h3>
            </div>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.agencyData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} unit="%" />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="rate" name="Qualification Rate" fill="#10b981" radius={[4, 4, 0, 0]} barSize={40}>
                    {stats.agencyData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
               {stats.agencyData.slice(0, 4).map((agency, idx) => (
                 <div key={idx} className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <p className="text-xs text-slate-500 uppercase font-bold truncate">{agency.name}</p>
                    <p className="text-xl font-bold text-slate-900">{agency.rate.toFixed(1)}%</p>
                    <p className="text-xs text-slate-400">{agency.qualified}/{agency.total} leads</p>
                 </div>
               ))}
            </div>
          </div>
        )}
      </div>

      {/* Insights & Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-amber-500" />
            Where to Improve
          </h3>
          <ul className="space-y-4">
            {stats.metrics.filter(m => m.mismatch > m.match).length > 0 ? (
              stats.metrics.filter(m => m.mismatch > m.match).map((m, i) => (
                <li key={i} className="flex gap-4 p-4 bg-amber-50 rounded-xl border border-amber-100">
                  <div className="w-2 h-2 mt-2 rounded-full bg-amber-500 shrink-0" />
                  <div>
                    <p className="font-semibold text-amber-900">{m.name} Mismatch</p>
                    <p className="text-sm text-amber-700">High volume of leads failing on {m.name.toLowerCase()} criteria. Consider broadening this parameter or refining lead sources.</p>
                  </div>
                </li>
              ))
            ) : (
              <li className="flex gap-4 p-4 bg-emerald-50 rounded-xl border border-emerald-100">
                <div className="w-2 h-2 mt-2 rounded-full bg-emerald-500 shrink-0" />
                <div>
                  <p className="font-semibold text-emerald-900">High Criteria Match</p>
                  <p className="text-sm text-emerald-700">Your current criteria are well-aligned with the incoming lead data.</p>
                </div>
              </li>
            )}
            {stats.avgConfidence < 70 && (
              <li className="flex gap-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
                <div className="w-2 h-2 mt-2 rounded-full bg-blue-500 shrink-0" />
                <div>
                  <p className="font-semibold text-blue-900">Low Confidence Scores</p>
                  <p className="text-sm text-blue-700">AI is uncertain about some results. Try providing more specific project context or clearer lead notes.</p>
                </div>
              </li>
            )}
          </ul>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
            Strategic Recommendations
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="font-semibold text-slate-900">Optimize Lead Sources</p>
              <p className="text-sm text-slate-600 mt-1">
                Focus budget on platforms generating "{stats.tagData[0]?.name || 'High Intent'}" tags as they show better qualification rates.
              </p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="font-semibold text-slate-900">Refine Project Context</p>
              <p className="text-sm text-slate-600 mt-1">
                If {stats.metrics.find(m => m.name === 'Budget')?.mismatch || 0} leads fail budget, consider adding "Flexible Budget" to your project tags.
              </p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="font-semibold text-slate-900">Real-time Feedback</p>
              <p className="text-sm text-slate-600 mt-1">
                Use the Test Playground to verify if your criteria are too strict for common lead comments.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
