import React, { useMemo } from 'react';
import { ProjectContext } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { 
  TrendingUp, Users, CheckCircle2, Building2, 
  ArrowLeft, BarChart3, Target, Zap, 
  Tag as TagIcon, PhoneCall, UserCheck, Briefcase
} from 'lucide-react';

interface GlobalDashboardProps {
  projects: ProjectContext[];
  onBack: () => void;
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316'];

const GlobalDashboard: React.FC<GlobalDashboardProps> = ({ projects, onBack }) => {
  const stats = useMemo(() => {
    if (projects.length === 0) return null;

    const totalProjects = projects.length;
    let totalLeads = 0;
    let totalQualified = 0;
    
    const projectPerformance = projects.map(p => {
      const stats = p.lastAnalysisStats || { total: 0, qualified: 0 };
      totalLeads += stats.total;
      totalQualified += stats.qualified;
      return {
        name: p.projectName,
        total: stats.total,
        qualified: stats.qualified,
        rate: stats.total > 0 ? (stats.qualified / stats.total) * 100 : 0
      };
    }).sort((a, b) => b.rate - a.rate);

    // Source Performance
    const sourceStats: Record<string, { total: number, qualified: number }> = {};
    const callCentreStats: Record<string, { total: number, qualified: number }> = {};
    const agentStats: Record<string, { total: number, qualified: number }> = {};

    projects.forEach(p => {
      const s = p.lastAnalysisStats || { total: 0, qualified: 0 };
      if (p.source) {
        if (!sourceStats[p.source]) sourceStats[p.source] = { total: 0, qualified: 0 };
        sourceStats[p.source].total += s.total;
        sourceStats[p.source].qualified += s.qualified;
      }
      if (p.callCentre) {
        if (!callCentreStats[p.callCentre]) callCentreStats[p.callCentre] = { total: 0, qualified: 0 };
        callCentreStats[p.callCentre].total += s.total;
        callCentreStats[p.callCentre].qualified += s.qualified;
      }
      if (p.agent) {
        if (!agentStats[p.agent]) agentStats[p.agent] = { total: 0, qualified: 0 };
        agentStats[p.agent].total += s.total;
        agentStats[p.agent].qualified += s.qualified;
      }
    });

    const formatData = (record: Record<string, { total: number, qualified: number }>) => 
      Object.entries(record).map(([name, data]) => ({
        name,
        total: data.total,
        qualified: data.qualified,
        rate: data.total > 0 ? (data.qualified / data.total) * 100 : 0
      })).sort((a, b) => b.rate - a.rate);

    return {
      totalProjects,
      totalLeads,
      totalQualified,
      avgRate: totalLeads > 0 ? (totalQualified / totalLeads) * 100 : 0,
      projectPerformance,
      sourceData: formatData(sourceStats),
      callCentreData: formatData(callCentreStats),
      agentData: formatData(agentStats)
    };
  }, [projects]);

  if (!stats) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white rounded-2xl border border-slate-200 shadow-sm">
        <BarChart3 className="w-16 h-16 text-slate-200 mb-4" />
        <h3 className="text-xl font-semibold text-slate-900">No Project Data</h3>
        <p className="text-slate-500 mb-6">Analyze some leads in your projects to see global insights.</p>
        <button 
          onClick={onBack}
          className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Global Insights Dashboard</h2>
          <p className="text-slate-500">Aggregated performance across all projects and tracking tags.</p>
        </div>
        <button 
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-slate-600"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Building2 className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Projects</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.totalProjects}</div>
          <div className="mt-2 text-sm text-slate-500">Active projects tracked</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-emerald-50 rounded-lg">
              <Users className="w-6 h-6 text-emerald-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Leads</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.totalLeads}</div>
          <div className="mt-2 text-sm text-slate-500">Across all projects</div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-amber-50 rounded-lg">
              <CheckCircle2 className="w-6 h-6 text-amber-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Overall CAPI Rate</span>
          </div>
          <div className="text-3xl font-bold text-slate-900">{stats.avgRate.toFixed(1)}%</div>
          <div className="mt-2 text-sm text-emerald-600 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            {stats.totalQualified} qualified leads
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-purple-50 rounded-lg">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Top Project</span>
          </div>
          <div className="text-2xl font-bold text-slate-900 truncate">
            {stats.projectPerformance[0]?.name || 'N/A'}
          </div>
          <div className="mt-2 text-sm text-slate-500">Highest qualification rate</div>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Project Performance */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-8 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-blue-600" />
            Project Performance (CAPI Rate %)
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.projectPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={120} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="rate" name="CAPI Rate" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Source Performance */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-8 flex items-center gap-2">
            <TagIcon className="w-5 h-5 text-emerald-600" />
            Source Performance
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.sourceData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} unit="%" />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="rate" name="CAPI Rate" fill="#10b981" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Call Centre Performance */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-8 flex items-center gap-2">
            <PhoneCall className="w-5 h-5 text-amber-600" />
            Call Centre Performance
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.callCentreData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} unit="%" />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="rate" name="CAPI Rate" fill="#f59e0b" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Agent Performance */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-8 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-purple-600" />
            Agent Performance
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.agentData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} unit="%" />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="rate" name="CAPI Rate" fill="#8b5cf6" radius={[4, 4, 0, 0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GlobalDashboard;
