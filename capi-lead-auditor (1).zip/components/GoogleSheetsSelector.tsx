import React, { useState, useEffect } from 'react';
import { Table, Loader2, Link2, AlertCircle } from 'lucide-react';
import { RawRow } from '../types';

interface GoogleSheetsSelectorProps {
  onDataLoaded: (data: RawRow[]) => void;
  onCancel: () => void;
}

const GoogleSheetsSelector: React.FC<GoogleSheetsSelectorProps> = ({ onDataLoaded, onCancel }) => {
  const [spreadsheetUrl, setSpreadsheetUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        setIsAuthenticated(true);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleConnect = async () => {
    try {
      const response = await fetch('/api/auth/url');
      const { url } = await response.json();
      window.open(url, 'google_oauth', 'width=600,height=700');
    } catch (err) {
      setError('Failed to get authentication URL');
    }
  };

  const handleFetchData = async () => {
    if (!spreadsheetUrl) return;
    
    // Extract spreadsheetId from URL
    const match = spreadsheetUrl.match(/\/d\/([a-zA-Z0-9-_]+)/);
    const spreadsheetId = match ? match[1] : spreadsheetUrl;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/sheets/data?spreadsheetId=${spreadsheetId}`);
      if (!response.ok) throw new Error('Failed to fetch data');
      
      const values = await response.json();
      if (!values || values.length === 0) {
        throw new Error('No data found in the spreadsheet');
      }

      // Convert array of arrays to array of objects
      const headers = values[0];
      const rows = values.slice(1).map((row: any[]) => {
        const obj: RawRow = {};
        headers.forEach((header: string, index: number) => {
          obj[header] = row[index] || '';
        });
        return obj;
      });

      onDataLoaded(rows);
    } catch (err: any) {
      setError(err.message || 'An error occurred while fetching data');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl p-10 animate-fade-in-up">
      <div className="flex items-center gap-4 mb-8">
        <div className="bg-green-100 p-3 rounded-2xl">
          <Table className="w-8 h-8 text-green-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Google Sheets Integration</h2>
          <p className="text-slate-500">Connect and import data directly from your sheets.</p>
        </div>
      </div>

      {!isAuthenticated ? (
        <div className="text-center py-10">
          <button
            onClick={handleConnect}
            className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-green-200 transition-all flex items-center gap-3 mx-auto"
          >
            Connect Google Account
          </button>
          <p className="text-sm text-slate-400 mt-4">We only request read-only access to your spreadsheets.</p>
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2">Spreadsheet URL or ID</label>
            <div className="relative">
              <input
                type="text"
                value={spreadsheetUrl}
                onChange={(e) => setSpreadsheetUrl(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/..."
                className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-all pl-14"
              />
              <Link2 className="absolute left-6 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-100 text-red-600 p-4 rounded-2xl flex items-center gap-3 text-sm">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-4">
            <button
              onClick={onCancel}
              className="flex-1 px-8 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl font-bold transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleFetchData}
              disabled={!spreadsheetUrl || isLoading}
              className="flex-1 px-8 py-4 bg-green-600 hover:bg-green-700 disabled:bg-green-300 text-white rounded-2xl font-bold shadow-lg shadow-green-200 transition-all flex items-center justify-center gap-3"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Fetching...
                </>
              ) : (
                'Import Data'
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GoogleSheetsSelector;
