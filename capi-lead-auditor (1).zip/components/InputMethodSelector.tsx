import React from 'react';
import { FileUp, Table, Type, Zap } from 'lucide-react';
import { InputMethod } from '../types';

interface InputMethodSelectorProps {
  onSelect: (method: InputMethod) => void;
  onBack: () => void;
}

const InputMethodSelector: React.FC<InputMethodSelectorProps> = ({ onSelect, onBack }) => {
  const methods = [
    {
      id: InputMethod.FILE,
      name: 'Excel / CSV File',
      description: 'Upload a local spreadsheet file from your computer.',
      icon: <FileUp className="w-8 h-8 text-blue-600" />,
      color: 'bg-blue-50'
    },
    {
      id: InputMethod.GOOGLE_SHEETS,
      name: 'Google Sheets',
      description: 'Import data directly from your Google Spreadsheets.',
      icon: <Table className="w-8 h-8 text-green-600" />,
      color: 'bg-green-50'
    },
    {
      id: InputMethod.COPY_PASTE,
      name: 'Copy-Paste / Real-time',
      description: 'Paste comments directly for instant analysis or CRM integration.',
      icon: <Type className="w-8 h-8 text-purple-600" />,
      color: 'bg-purple-50'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto animate-fade-in-up">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Choose Input Method</h2>
        <p className="text-lg text-slate-600">Select how you want to provide the lead data for auditing.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {methods.map((method) => (
          <button
            key={method.id}
            onClick={() => onSelect(method.id)}
            className="flex flex-col items-center p-8 bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all text-center group"
          >
            <div className={`${method.color} p-4 rounded-xl mb-6 group-hover:scale-110 transition-transform`}>
              {method.icon}
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">{method.name}</h3>
            <p className="text-sm text-slate-500">{method.description}</p>
          </button>
        ))}
      </div>

      <div className="mt-12 flex justify-center">
        <button
          onClick={onBack}
          className="text-slate-500 hover:text-slate-800 font-medium transition-colors"
        >
          ← Back to Project Setup
        </button>
      </div>
    </div>
  );
};

export default InputMethodSelector;
