import React, { useState, useEffect } from 'react';
import { ProjectContext, Configuration } from '../types';
import { X, Plus, Trash2, Building2, MapPin, IndianRupee, Calendar, ChevronDown } from 'lucide-react';

interface ProjectContextInputProps {
  initialData?: ProjectContext | null;
  onConfirm: (context: ProjectContext) => void;
  onCancel: () => void;
}

const ProjectContextInput: React.FC<ProjectContextInputProps> = ({ initialData, onConfirm, onCancel }) => {
  const [projectName, setProjectName] = useState(initialData?.projectName || '');
  const [location, setLocation] = useState(initialData?.location || '');
  const [propertyType, setPropertyType] = useState<ProjectContext['propertyType']>(initialData?.propertyType || 'Residential');
  const [startBudget, setStartBudget] = useState(initialData?.startBudget || '');
  const [targetPossession, setTargetPossession] = useState(initialData?.targetPossession || '');
  const [source, setSource] = useState(initialData?.source || '');
  const [callCentre, setCallCentre] = useState(initialData?.callCentre || '');
  const [agent, setAgent] = useState(initialData?.agent || '');
  const [capiMatchRequirements, setCapiMatchRequirements] = useState<string[]>(
    initialData?.capiMatchRequirements || ['Budget', 'Location']
  );
  const [customCapiPrompt, setCustomCapiPrompt] = useState(initialData?.customCapiPrompt || '');
  
  const [configurations, setConfigurations] = useState<Configuration[]>(
    initialData?.configurations || [{ type: '', size: '', price: '' }]
  );

  const [availableTags, setAvailableTags] = useState<{ id: string, name: string, type: string }[]>(() => {
    const saved = localStorage.getItem('capi_tags');
    return saved ? JSON.parse(saved) : [];
  });

  const sources = availableTags.filter(t => t.type === 'source');
  const callCentres = availableTags.filter(t => t.type === 'callCentre');
  const agents = availableTags.filter(t => t.type === 'agent');

  const handleAddRow = () => {
    setConfigurations([...configurations, { type: '', size: '', price: '' }]);
  };

  const handleRemoveRow = (index: number) => {
    if (configurations.length > 1) {
      setConfigurations(configurations.filter((_, i) => i !== index));
    }
  };

  const handleConfigChange = (index: number, field: keyof Configuration, value: string) => {
    const newConfigs = [...configurations];
    newConfigs[index][field] = value;
    setConfigurations(newConfigs);
  };

  const toggleMatchRequirement = (req: string) => {
    setCapiMatchRequirements(prev => 
      prev.includes(req) 
        ? prev.filter(r => r !== req) 
        : [...prev, req]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm({
      id: initialData?.id || Math.random().toString(36).substr(2, 9),
      projectName,
      location,
      propertyType,
      startBudget,
      targetPossession,
      configurations,
      source,
      callCentre,
      agent,
      capiMatchRequirements,
      customCapiPrompt,
      lastAnalysisStats: initialData?.lastAnalysisStats
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Header */}
        <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-slate-800">
            {initialData ? 'Edit Project' : 'Add New Project'}
          </h2>
          <button onClick={onCancel} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6 max-h-[80vh] overflow-y-auto custom-scrollbar">
          {/* Project Name */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Project Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Nexspace Panvel"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Location */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Location</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. Panvel"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              </div>
            </div>

            {/* Property Type */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Property Type</label>
              <div className="relative">
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value as any)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all appearance-none"
                >
                  <option value="Residential">Residential</option>
                  <option value="Commercial">Commercial</option>
                  <option value="Plots">Plots</option>
                  <option value="Other">Other</option>
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
              </div>
            </div>

            {/* Start Budget */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Start Budget (CR)</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="0.79"
                  value={startBudget}
                  onChange={(e) => setStartBudget(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
                <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              </div>
            </div>

            {/* Target Possession */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Target Possession</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  placeholder="e.g. January 2032"
                  value={targetPossession}
                  onChange={(e) => setTargetPossession(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                />
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>

          {/* Lead Tagging Section */}
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
            <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <Plus className="w-4 h-4 text-blue-600" /> Lead Tracking Tags
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Source</label>
                <select
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">Select Source</option>
                  {sources.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Call Centre</label>
                <select
                  value={callCentre}
                  onChange={(e) => setCallCentre(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">Select Call Centre</option>
                  {callCentres.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Agent</label>
                <select
                  value={agent}
                  onChange={(e) => setAgent(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="">Select Agent</option>
                  {agents.map(a => <option key={a.id} value={a.name}>{a.name}</option>)}
                </select>
              </div>
            </div>
            <p className="text-[10px] text-slate-400 italic">Manage these options in the Tag Management section.</p>
          </div>

          {/* Configurations */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Configurations (Type, Size & Price)</label>
              <button
                type="button"
                onClick={handleAddRow}
                className="text-blue-600 hover:text-blue-700 text-xs font-bold flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3 h-3" /> Add Row
              </button>
            </div>

            <div className="space-y-3">
              {configurations.map((config, index) => (
                <div key={index} className="flex items-center gap-3 group animate-fade-in">
                  <input
                    type="text"
                    placeholder="Type (e.g. 2 BHK)"
                    value={config.type}
                    onChange={(e) => handleConfigChange(index, 'type', e.target.value)}
                    className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                  <input
                    type="text"
                    placeholder="Size"
                    value={config.size}
                    onChange={(e) => handleConfigChange(index, 'size', e.target.value)}
                    className="w-24 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                  />
                  <div className="relative w-32">
                    <input
                      type="text"
                      placeholder="Price"
                      value={config.price}
                      onChange={(e) => handleConfigChange(index, 'price', e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all pr-8"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">Cr</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(index)}
                    disabled={configurations.length === 1}
                    className="p-2 text-slate-300 hover:text-red-500 disabled:opacity-0 transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* CAPI Logic Rules */}
          <div className="p-6 bg-blue-50/50 rounded-2xl border border-blue-100 space-y-4">
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800">CAPI Qualification Logic</h3>
              <p className="text-xs text-slate-500">Define what criteria must match for a lead to be marked as CAPI (Qualified).</p>
            </div>
            
            <div className="space-y-3 pt-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Required Matches</label>
              <div className="flex flex-wrap gap-3">
                {['Location', 'Budget', 'Configuration', 'Target Possession'].map(req => (
                  <label key={req} className="flex items-center gap-2 cursor-pointer bg-white px-4 py-2 rounded-xl border border-slate-200 hover:border-blue-300 transition-colors">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500"
                      checked={capiMatchRequirements.includes(req)}
                      onChange={() => toggleMatchRequirement(req)}
                    />
                    <span className="text-sm font-medium text-slate-700">{req}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-4 border-t border-blue-100/50">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Custom Prompt Rules (Optional)</label>
              <p className="text-[10px] text-slate-500 mb-2">Give the AI highly specific instructions for this project. E.g. "Only mark CAPI if they specifically want a sea-facing view."</p>
              <textarea
                rows={3}
                placeholder="Enter any additional rules or nuances the AI should follow..."
                value={customCapiPrompt}
                onChange={(e) => setCustomCapiPrompt(e.target.value)}
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none text-sm"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-6 flex items-center justify-end gap-4">
            <button
              type="button"
              onClick={onCancel}
              className="px-6 py-3 text-slate-500 font-bold hover:text-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-10 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-200 transition-all transform hover:translate-y-[-1px]"
            >
              Save Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProjectContextInput;
