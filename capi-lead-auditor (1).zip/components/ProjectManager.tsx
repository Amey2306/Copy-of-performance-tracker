import React from 'react';
import { ProjectContext } from '../types';
import { Plus, Edit2, Trash2, Building2, MapPin, IndianRupee, Calendar, ArrowRight } from 'lucide-react';

interface ProjectManagerProps {
  projects: ProjectContext[];
  onAdd: () => void;
  onEdit: (project: ProjectContext) => void;
  onDelete: (id: string) => void;
  onSelect: (project: ProjectContext) => void;
}

const ProjectManager: React.FC<ProjectManagerProps> = ({ projects, onAdd, onEdit, onDelete, onSelect }) => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Your Projects</h2>
          <p className="text-slate-500">Select a project to start analyzing leads or manage your project criteria.</p>
        </div>
        <button
          onClick={onAdd}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-blue-200 transition-all transform hover:translate-y-[-1px]"
        >
          <Plus className="w-5 h-5" />
          Add New Project
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-20 text-center">
          <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Building2 className="w-10 h-10 text-slate-300" />
          </div>
          <h3 className="text-xl font-bold text-slate-800 mb-2">No projects yet</h3>
          <p className="text-slate-500 mb-8 max-w-sm mx-auto">
            Create your first project to define the criteria for AI lead qualification.
          </p>
          <button
            onClick={onAdd}
            className="text-blue-600 font-bold hover:underline"
          >
            Click here to get started
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              className="group bg-white border border-slate-200 rounded-3xl p-6 hover:border-blue-500 hover:shadow-xl hover:shadow-blue-500/5 transition-all relative overflow-hidden"
            >
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-blue-50 p-3 rounded-2xl group-hover:bg-blue-600 transition-colors">
                  <Building2 className="w-6 h-6 text-blue-600 group-hover:text-white" />
                </div>
                <div className="ml-auto flex items-center gap-2">
                  <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded uppercase tracking-wider">
                    {project.propertyType}
                  </span>
                  <button
                    onClick={() => onEdit(project)}
                    className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                    title="Edit Project"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDelete(project.id)}
                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                    title="Delete Project"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <h3 className="text-xl font-bold text-slate-800 mb-2">{project.projectName}</h3>
              
              <div className="space-y-3 mb-8">
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <MapPin className="w-4 h-4" />
                  {project.location}
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <IndianRupee className="w-4 h-4" />
                  Starts from {project.startBudget} Cr
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500">
                  <Calendar className="w-4 h-4" />
                  Possession: {project.targetPossession}
                </div>
              </div>

              {/* Tagging Info */}
              {(project.source || project.callCentre || project.agent) && (
                <div className="mb-6 p-3 bg-slate-50 rounded-2xl border border-slate-100 flex flex-wrap gap-3">
                  {project.source && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                      {project.source}
                    </div>
                  )}
                  {project.callCentre && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      {project.callCentre}
                    </div>
                  )}
                  {project.agent && (
                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                      {project.agent}
                    </div>
                  )}
                </div>
              )}

              {/* Last Analysis Stats */}
              {project.lastAnalysisStats && (
                <div className="mb-6 grid grid-cols-2 gap-3">
                  <div className="bg-blue-50/50 p-2 rounded-xl border border-blue-100/50 text-center">
                    <p className="text-[10px] font-bold text-blue-600 uppercase">Qualified</p>
                    <p className="text-lg font-bold text-blue-700">
                      {project.lastAnalysisStats.qualified}/{project.lastAnalysisStats.total}
                    </p>
                  </div>
                  <div className="bg-emerald-50/50 p-2 rounded-xl border border-emerald-100/50 text-center">
                    <p className="text-[10px] font-bold text-emerald-600 uppercase">Rate</p>
                    <p className="text-lg font-bold text-emerald-700">
                      {((project.lastAnalysisStats.qualified / project.lastAnalysisStats.total) * 100).toFixed(0)}%
                    </p>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2 mb-8">
                {project.configurations.slice(0, 2).map((config, idx) => (
                  <span key={idx} className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                    {config.type}
                  </span>
                ))}
                {project.configurations.length > 2 && (
                  <span className="bg-slate-100 text-slate-600 text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                    +{project.configurations.length - 2} More
                  </span>
                )}
              </div>

              <button
                onClick={() => onSelect(project)}
                className="w-full flex items-center justify-center gap-2 py-3 bg-slate-50 group-hover:bg-blue-600 text-slate-600 group-hover:text-white font-bold rounded-2xl transition-all"
              >
                Select Project
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProjectManager;
