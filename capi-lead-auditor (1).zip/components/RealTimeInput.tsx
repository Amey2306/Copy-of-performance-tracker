import React, { useState } from 'react';
import { Type, Zap, Loader2, Send } from 'lucide-react';
import { ProjectContext, AnalysisResult } from '../types';
import { analyzeSingleLead } from '../services/geminiService';

interface RealTimeInputProps {
  projectContext: ProjectContext;
  onAnalysisComplete: (result: AnalysisResult) => void;
  onBack: () => void;
}

const RealTimeInput: React.FC<RealTimeInputProps> = ({ projectContext, onAnalysisComplete, onBack }) => {
  const [comment, setComment] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    if (!comment.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const result = await analyzeSingleLead(comment, projectContext);
      onAnalysisComplete({
        rowId: Date.now(),
        originalData: { 'Comment': comment },
        ...result
      });
      setComment('');
    } catch (error) {
      console.error("Real-time analysis error:", error);
      alert("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-xl p-10 animate-fade-in-up">
      <div className="flex items-center gap-4 mb-8">
        <div className="bg-purple-100 p-3 rounded-2xl">
          <Zap className="w-8 h-8 text-purple-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Real-time Lead Analysis</h2>
          <p className="text-slate-500">Paste a call note or comment to instantly qualify the lead.</p>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-2">Call Note / Comment</label>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="e.g., Customer is looking for 2BHK in Wadala, budget is around 6Cr, possession by 2030..."
            className="w-full h-48 px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-all resize-none"
          />
        </div>

        <div className="flex gap-4">
          <button
            onClick={onBack}
            className="flex-1 px-8 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl font-bold transition-all"
          >
            Back
          </button>
          <button
            onClick={handleAnalyze}
            disabled={!comment.trim() || isAnalyzing}
            className="flex-1 px-8 py-4 bg-purple-600 hover:bg-purple-700 disabled:bg-purple-300 text-white rounded-2xl font-bold shadow-lg shadow-purple-200 transition-all flex items-center justify-center gap-3"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                Analyze Now
              </>
            )}
          </button>
        </div>
      </div>

      <div className="mt-8 pt-8 border-t border-slate-100">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">CRM Integration Tip</h4>
        <p className="text-sm text-slate-500 leading-relaxed">
          You can integrate this tool with your CRM using our API endpoint. 
          Simply send a POST request to <code className="bg-slate-100 px-2 py-1 rounded">/api/analyze</code> 
          with the lead data to automate your qualification process.
        </p>
      </div>
    </div>
  );
};

export default RealTimeInput;
