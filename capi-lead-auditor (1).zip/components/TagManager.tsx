import React, { useState, useEffect } from 'react';
import { Tag } from '../types';
import { Plus, Trash2, Edit2, Check, X, Tag as TagIcon, Users, PhoneCall, UserCheck } from 'lucide-react';

interface TagManagerProps {
  onBack: () => void;
}

const TagManager: React.FC<TagManagerProps> = ({ onBack }) => {
  const [tags, setTags] = useState<Tag[]>(() => {
    const saved = localStorage.getItem('capi_tags');
    return saved ? JSON.parse(saved) : [];
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<'source' | 'callCentre' | 'agent'>('source');

  useEffect(() => {
    localStorage.setItem('capi_tags', JSON.stringify(tags));
  }, [tags]);

  const addTag = () => {
    if (!newName.trim()) return;
    const newTag: Tag = {
      id: crypto.randomUUID(),
      name: newName.trim(),
      type: newType
    };
    setTags([...tags, newTag]);
    setNewName('');
  };

  const deleteTag = (id: string) => {
    setTags(tags.filter(t => t.id !== id));
  };

  const startEditing = (tag: Tag) => {
    setEditingId(tag.id);
    setEditName(tag.name);
  };

  const saveEdit = () => {
    setTags(tags.map(t => t.id === editingId ? { ...t, name: editName } : t));
    setEditingId(null);
  };

  const renderTagList = (type: 'source' | 'callCentre' | 'agent', title: string, icon: React.ReactNode) => {
    const filteredTags = tags.filter(t => t.type === type);
    return (
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 bg-slate-100 rounded-lg text-slate-600">
            {icon}
          </div>
          <h3 className="text-lg font-bold text-slate-900">{title}</h3>
        </div>

        <div className="space-y-3">
          {filteredTags.map(tag => (
            <div key={tag.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 group">
              {editingId === tag.id ? (
                <div className="flex items-center gap-2 flex-1">
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="flex-1 px-2 py-1 text-sm border border-blue-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    autoFocus
                  />
                  <button onClick={saveEdit} className="p-1 text-green-600 hover:bg-green-50 rounded">
                    <Check className="w-4 h-4" />
                  </button>
                  <button onClick={() => setEditingId(null)} className="p-1 text-red-600 hover:bg-red-50 rounded">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <>
                  <span className="text-sm font-medium text-slate-700">{tag.name}</span>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => startEditing(tag)} className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteTag(tag.id)} className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
          {filteredTags.length === 0 && (
            <p className="text-sm text-slate-400 text-center py-4">No {title.toLowerCase()} added yet.</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Tag Management</h2>
          <p className="text-slate-500">Manage sources, call centres, and agents for lead tracking.</p>
        </div>
        <button
          onClick={onBack}
          className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
        >
          Back
        </button>
      </div>

      {/* Add New Tag */}
      <div className="bg-blue-600 p-8 rounded-2xl shadow-lg shadow-blue-200 text-white">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Plus className="w-6 h-6" /> Add New Tracking Tag
        </h3>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-blue-100 mb-1">Tag Name</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Facebook Ads, Mumbai Hub, Agent Rahul"
              className="w-full px-4 py-2 bg-blue-700 border border-blue-500 rounded-xl text-white placeholder-blue-300 focus:outline-none focus:ring-2 focus:ring-white/50"
            />
          </div>
          <div className="w-full md:w-48">
            <label className="block text-sm font-medium text-blue-100 mb-1">Type</label>
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value as any)}
              className="w-full px-4 py-2 bg-blue-700 border border-blue-500 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-white/50"
            >
              <option value="source">Source</option>
              <option value="callCentre">Call Centre</option>
              <option value="agent">Agent</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              onClick={addTag}
              className="w-full md:w-auto px-8 py-2 bg-white text-blue-600 font-bold rounded-xl hover:bg-blue-50 transition-colors"
            >
              Add Tag
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {renderTagList('source', 'Sources', <TagIcon className="w-5 h-5" />)}
        {renderTagList('callCentre', 'Call Centres', <PhoneCall className="w-5 h-5" />)}
        {renderTagList('agent', 'Agents', <UserCheck className="w-5 h-5" />)}
      </div>
    </div>
  );
};

export default TagManager;
