import * as XLSX from 'xlsx';
import { RawRow, AnalysisResult } from '../types';

export const parseExcelFile = (file: File): Promise<RawRow[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON
        const json = XLSX.utils.sheet_to_json<RawRow>(worksheet, { defval: "" });
        resolve(json);
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsBinaryString(file);
  });
};

export const exportToExcel = (results: AnalysisResult[], originalFileName: string) => {
  // Merge original data with new analysis columns
  const exportData = results.map(r => ({
    ...r.originalData,
    'AI_CAPI_Updated': r.capiUpdated ? 'TRUE' : 'FALSE',
    'AI_Confidence': r.confidenceScore ? `${Math.round(r.confidenceScore * 100)}%` : 'N/A',
    'AI_Tags': r.tags ? r.tags.join(', ') : '',
    'AI_Reason': r.reason
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Lead Analysis");

  // Generate filename
  const fileNameParts = originalFileName.split('.');
  const name = fileNameParts.slice(0, -1).join('.');
  const ext = fileNameParts[fileNameParts.length - 1];
  const newFileName = `${name}_analyzed.${ext}`;

  XLSX.writeFile(workbook, newFileName);
};
