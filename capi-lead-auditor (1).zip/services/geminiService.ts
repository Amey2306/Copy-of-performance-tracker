import { GoogleGenAI, Type } from "@google/genai";
import { ProjectContext } from "../types";

const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({ apiKey: apiKey });

const modelId = "gemini-3-flash-preview"; 

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      rowId: { type: Type.INTEGER, description: "The index of the row from the input array" },
      capiUpdated: { type: Type.BOOLEAN, description: "Whether the lead matches the CAPI criteria for this specific project" },
      reason: { type: Type.STRING, description: "Explanation of which project specific criteria were MATCHED (e.g., 'Matched Location (Wadala) and Config (2BHK)')" },
      confidenceScore: { type: Type.NUMBER, description: "A score between 0.0 and 1.0 indicating how confident the AI is based on the clarity of the notes." },
      tags: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: "A list of tags to categorize the lead (e.g., 'Hot Lead', 'Budget Mismatch', 'Location Issue', 'Configuration Mismatch', 'Possession Issue', 'Vague Notes')"
      }
    },
    required: ["rowId", "capiUpdated", "reason", "confidenceScore", "tags"]
  }
};

interface BatchItem {
  rowId: number;
  text: string;
}

export const analyzeLeadBatch = async (batch: BatchItem[], context: ProjectContext): Promise<Array<{ rowId: number, capiUpdated: boolean, reason: string, confidenceScore: number, tags: string[] }>> => {
  try {
    const configString = context.configurations.map(c => `${c.type} (${c.size}, ${c.price} Cr)`).join(', ');
    
    const requiredMatches = context.capiMatchRequirements && context.capiMatchRequirements.length > 0 
      ? context.capiMatchRequirements 
      : ['Budget', 'Location']; // Default fallback
      
    const requiredMatchesStr = requiredMatches.join(' AND ');

    const customPromptStr = context.customCapiPrompt 
      ? `\n**Custom Nuance/Rules for this Project:**\n${context.customCapiPrompt}\n`
      : '';

    const SYSTEM_INSTRUCTION = `
You are a Senior Quality Analyst for a Real Estate Pre-sales team. 
Your task is to analyze "Call Notes" to determine if a lead is "CAPI" (Quality Lead) for a SPECIFIC PROJECT: "${context.projectName}".

**Target Project Criteria:**
1. **Budget**: Starting from ${context.startBudget} Cr
2. **Location**: ${context.location}
3. **Configuration**: ${configString}
4. **Possession**: ${context.targetPossession}
5. **Property Type**: ${context.propertyType}

**CAPI Qualification Logic (CRITICAL RULE):**
Based on the configured logic for this project, a lead is considered "CAPI" (True) ONLY IF the user's requirements discussed in the notes **MATCH ALL of the following criteria**:
[ **${requiredMatchesStr}** ]

**Core Logic:**
- Merely discussing a topic is NOT enough; the user's need must ALIGN with the project.
- ALL of the REQUIRED MATCHES listed above MUST align with the project parameters.
- If ANY of the required criteria is explicitly mismatched, CAPI is FALSE.
- If ANY of the required criteria is missing or unknown from the notes, CAPI is FALSE (flag as Need details).
${customPromptStr}

**Confidence Score:**
- Assign a confidence score (0.0 to 1.0).
- High (0.9+): Clear facts in notes matching or mismatching criteria.
- Low (<0.5): Vague notes, ambiguous statements, or insufficient info to decide.

**Tagging:**
- Categorize the lead with relevant tags.
- Use tags like: "Hot Lead" (CAPI True), "Budget Mismatch", "Location Issue", "Configuration Mismatch", "Possession Issue", "Vague Notes", "Follow-up Required".
- A lead can have multiple tags.

**Examples (Assuming Budget AND Location are required):**
- Note: "Interested in Wadala, looking for 2BHK, Budget 6Cr." (Project: Wadala, 5.5cr) -> Matches Location + Budget -> **CAPI TRUE**.
- Note: "Looking for 2BHK in Wadala." (Project: Wadala, 5.5cr, but budget unknown) -> Missing Budget information. Since Budget is required, this is NOT fully qualified. -> **CAPI FALSE** (Tag with "Need Budget Details").
- Note: "Ok with 5.5cr budget and 2030 possession but wants Malad." (Project: Wadala) -> Location Mismatch -> **CAPI FALSE**.

*(Note: Apply the above reasoning strictly according to the actual configured REQUIRED MATCHES [ **${requiredMatchesStr}** ] and Custom Rules).*

Input notes may be messy. Ignore general greetings. Focus on the hard facts extracted from the conversation.
`;

    const prompt = `
      Analyze the following batch of call notes against the project rules for "${context.projectName}".
      Return a JSON array matching the schema.
      
      Input Data:
      ${JSON.stringify(batch)}
    `;

    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.1, 
      }
    });

    const jsonText = response.text;
    if (!jsonText) return [];
    
    return JSON.parse(jsonText);
  } catch (error) {
    console.error("Gemini Batch Error:", error);
    return [];
  }
};

export const analyzeSingleLead = async (text: string, context: ProjectContext): Promise<{ capiUpdated: boolean, reason: string, confidenceScore: number, tags: string[] }> => {
  const result = await analyzeLeadBatch([{ rowId: 1, text }], context);
  if (result && result.length > 0) {
    return result[0];
  }
  return { capiUpdated: false, reason: "Analysis failed", confidenceScore: 0, tags: [] };
};
