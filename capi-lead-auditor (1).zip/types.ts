export interface RawRow {
  [key: string]: string | number | boolean | null;
}

export interface Configuration {
  type: string;
  size: string;
  price: string;
}

export interface ProjectContext {
  id: string;
  projectName: string;
  location: string;
  propertyType: 'Residential' | 'Commercial' | 'Plots' | 'Other';
  startBudget: string;
  targetPossession: string;
  configurations: Configuration[];
  source?: string;
  callCentre?: string;
  agent?: string;
  capiMatchRequirements?: string[]; // e.g. ['Budget', 'Location', 'Configuration', 'Possession']
  customCapiPrompt?: string;
  lastAnalysisStats?: {
    total: number;
    qualified: number;
    timestamp: string;
  };
}

export interface Tag {
  id: string;
  name: string;
  type: 'source' | 'callCentre' | 'agent';
}

export interface AnalysisResult {
  rowId: number;
  originalData: RawRow;
  capiUpdated: boolean;
  reason: string;
  confidenceScore?: number;
  tags?: string[];
}

export interface ProcessingStats {
  total: number;
  processed: number;
  validCapi: number;
  invalidCapi: number;
}

export enum InputMethod {
  FILE = 'FILE',
  GOOGLE_SHEETS = 'GOOGLE_SHEETS',
  COPY_PASTE = 'COPY_PASTE'
}

export enum AppState {
  CONTEXT_SETUP = 'CONTEXT_SETUP',
  INPUT_METHOD = 'INPUT_METHOD',
  UPLOAD = 'UPLOAD',
  SHEETS = 'SHEETS',
  MAPPING = 'MAPPING',
  PROCESSING = 'PROCESSING',
  RESULTS = 'RESULTS',
  REALTIME = 'REALTIME',
  DASHBOARD = 'DASHBOARD',
  GLOBAL_DASHBOARD = 'GLOBAL_DASHBOARD',
  TAG_MANAGEMENT = 'TAG_MANAGEMENT'
}
